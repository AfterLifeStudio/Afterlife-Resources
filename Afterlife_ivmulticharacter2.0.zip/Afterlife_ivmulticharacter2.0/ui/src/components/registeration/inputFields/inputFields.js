export const inputFields = [
  { id: 1, name: 'firstName', placeholder: 'FIRST NAME' },
  { id: 2, name: 'lastName', placeholder: 'LAST NAME' },
  { id: 3, name: 'DOB', placeholder: 'DATE OF BIRTH' },
  { id: 4, name: 'nationality', placeholder: 'NATIONALITY' },
  { id: 5, name: 'height', placeholder: 'HEIGHT' },
  { id: 6, name: 'gender', placeholder: 'GENDER' }
]
