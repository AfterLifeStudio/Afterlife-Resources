

export const progress = [
    {
        value: 10,
        text: 'LOADING SESSION'
    },
    {
        value: 50,
        text: 'LOADING CHARACTERS'
    }
]