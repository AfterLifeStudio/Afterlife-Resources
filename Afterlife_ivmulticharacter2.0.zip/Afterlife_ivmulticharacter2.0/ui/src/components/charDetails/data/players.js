

export const players = [
  {
    id: 1,
    firstname: 'Osman',
    lastname: 'Saleem',
    emptyslot: true,
    img: false,
    additionalInfo: {
      type: 'Civilian',
      currencyInHand: 1000,
      currencyInBank: 10000000,
      DOB: '2004-02-01',
      nationality: 'PAKISTAN',
    }
  },
  {
    id: 2,
    firstname: 'Steve',
    lastname: 'Smith',
    sex: 'male',
    emptyslot: true,
    img: false,
    additionalInfo: {
      type: 'Police',
      currencyInHand: 5000,
      currencyInBank: 9000000,
      DOB: '2002-12-5',
      nationality: 'PAKISTAN',
    }
  },

  {
    id: 3,
    firstname: 'First Name',
    lastname: 'Last Name',
    emptyslot: true,
    img: false,
    additionalInfo: {
      type: 'JOB',
      currencyInHand: 'CASH',
      currencyInBank: 'BANK',
      DOB: 'DATE OF BIRTH',
      nationality: 'NATIONALITY',
    }
  },
  {
    id: 4,
    firstname: 'First Name',
    lastname: 'Last Name',
    emptyslot: true,
    img: false,
    additionalInfo: {
      type: 'JOB',
      currencyInHand: 'CASH',
      currencyInBank: 'BANK',
      DOB: 'DATE OF BIRTH',
      nationality: 'NATIONALITY',
    }
  },

]
