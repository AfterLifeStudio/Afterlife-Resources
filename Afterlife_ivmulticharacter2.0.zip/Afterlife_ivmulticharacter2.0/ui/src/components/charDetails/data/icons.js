import job from '../../../assets/job.png'
import cash from '../../../assets/cash.png'
import bank from '../../../assets/bank.png'
import dob from '../../../assets/dob.png'
import nationality from '../../../assets/nationality.png'

export const icons = [
  { id: 1, icon: job },
  { id: 2, icon: cash },
  { id: 3, icon: bank },
  { id: 4, icon: dob },
  { id: 5, icon: nationality }
]
