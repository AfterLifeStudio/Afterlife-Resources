

export const credits = [
    {
        title: 'Director',
        description: 'JGUsman'
    },
    {
        title: 'Lead Developer',
        description: 'JGUsman'
    },
    {
        title: 'UI Developer',
        description: 'Hammas (my big B)'
    },
    {
        title: 'UI Designer',
        description: 'ofc me again'
    },
    {
        title: 'IDK what',
        description: 'to put here'
    },

] 
