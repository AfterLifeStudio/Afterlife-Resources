import './App.css'
import Menu from './components/menu'
import Instructions from './components/instructions'

function App() {



  return (
    <>
    <Instructions />
    <Menu />
    </>
  )
}

export default App
