local voice








hunger = 100
thirst = 100
stress = 0
showmap = false
Voicemode = 2




CreateThread(function()
    while true do
        local health = GetEntityHealth(cache.ped)
        local armour = GetPedArmour(cache.ped)
        local oxygen
        if not IsEntityInWater(cache.ped) then
            oxygen = 100 - GetPlayerSprintStaminaRemaining(cache.playerId)
        end
        -- Oxygen
        if IsEntityInWater(cache.ped) then
            oxygen = GetPlayerUnderwaterTimeRemaining(cache.playerId) * 10
        end

        voice = NetworkIsPlayerTalking(cache.playerId)




        if (GlobalSettings.vehicleminimap and (cache.vehicle == false)) then
            showmap = false
        else
            showmap = true
        end



        local data = {
            status = {
                [0] = health - 100,
                [1] = armour,
                [2] = hunger,
                [3] = thirst,
                [4] = oxygen > 99 and  0 or oxygen,
                [5] = Config.stress and stress or 0,
            },

            minimap = showmap,
            voice = voice,
            voicemode = Voicemode
        }
        NuiMessage('status', data)
        Wait(500)
    end
end)





AddEventHandler('pma-voice:setTalkingMode', function(mode)
    Voicemode = mode
end)
