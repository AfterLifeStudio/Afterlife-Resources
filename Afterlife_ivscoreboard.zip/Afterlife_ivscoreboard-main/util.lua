
NuiMessage = function (action,data)
    SendNUIMessage({
        action = action,
        data = data
    })
end

NuiControl = function (state)
    SetNuiFocus(state, state)
end

TableCopy = function (t)
    local table = {}
    for i = 1,#t do
        table[i] = {
            name = t[i].name,
            label = t[i].label,
            count = t[i].count
        }
    end

    return table
end