if Config.framework == 'qbx' then

	lib.callback.register('scoreboard:getplayers', function()
		return exports.qbx_core:GetQBPlayers()
	end)

	lib.callback.register('scoreboard:getextra', function(source,player)
		return IsPlayerAceAllowed(player, Config.admingroup) ,GetPlayerPing(player)
	end)


	RegisterNetEvent('QBCore:Server:PlayerLoaded', function()
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)

	RegisterNetEvent('QBCore:Server:OnPlayerUnload', function()
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)

	AddEventHandler('QBCore:Server:OnJobUpdate', function() 
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)
end
