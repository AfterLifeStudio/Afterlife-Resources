if Config.framework == 'qb' then
	local QBCore = exports['qb-core']:GetCoreObject()

	lib.callback.register('scoreboard:getplayers', function()
		return QBCore.Functions.GetQBPlayers()



	end)

	lib.callback.register('scoreboard:getextra', function(source,player)
		return IsPlayerAceAllowed(player, Config.admingroup) ,GetPlayerPing(player)
	end)

	RegisterNetEvent('QBCore:Server:PlayerLoaded', function()
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)

	RegisterNetEvent('QBCore:Server:OnPlayerUnload', function()
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)

	RegisterNetEvent('QBCore:Player:SetPlayerData', function()
		TriggerClientEvent('scoreboard:updateplayers', -1)
	end)
end
