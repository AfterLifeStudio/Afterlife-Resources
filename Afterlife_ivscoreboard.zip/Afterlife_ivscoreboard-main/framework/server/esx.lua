if Config.framework == 'esx' then
    ESX = exports["es_extended"]:getSharedObject()

    lib.callback.register('scoreboard:getplayers', function()
        return ESX.GetExtendedPlayers()
    end)

    lib.callback.register('scoreboard:getextra', function(source,player)
		return false ,GetPlayerPing(player)
	end)


    RegisterNetEvent('esx:playerLoaded', function()
        TriggerClientEvent('scoreboard:updateplayers', -1)
    end)

    RegisterNetEvent('esx:playerDropped', function()
        TriggerClientEvent('scoreboard:updateplayers', -1)
    end)

    RegisterNetEvent('esx:setJob', function(player, job, lastJob)
		TriggerClientEvent('scoreboard:updateplayers', -1)
    end)
end
