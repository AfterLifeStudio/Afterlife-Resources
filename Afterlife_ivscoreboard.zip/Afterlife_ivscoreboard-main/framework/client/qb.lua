
if Config.framework == 'qb' then
    ReturnTable = function(result)
        local options = {}
        local jobs = TableCopy(Config.jobs)
        for i = 1, #result do
            local PlayerData = result[i].PlayerData
            local additionalinfo = {}

            local isadmin, ping =  lib.callback.await('scoreboard:getextra', false, PlayerData.source)

            if Config.additionalinfo then
                additionalinfo = {
                    PlayerData.citizenid,
                    PlayerData.job.label,
                    PlayerData.charinfo.gender == 0 and 'Male' or 'Female',
                }
            end

            options[#options + 1] = {
                id = PlayerData.source,
                firstname = Config.rpname and PlayerData.charinfo.firstname or PlayerData.name,
                lastname = Config.rpname and PlayerData.charinfo.lastname or '',
                ping =  ping,
                isadmin = isadmin,
                job = PlayerData.job.name,
                additionalinfo = additionalinfo
            }



            for k = 1,#jobs do
                if jobs[k].name == PlayerData.job.name then
                    jobs[k].count = jobs[k].count + 1
                end
            end
            
        end

        return options, jobs
    end
end
