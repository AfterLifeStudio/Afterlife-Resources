if Config.framework == 'esx' then
    ReturnTable = function(result)
        local options = {}
        local jobs = TableCopy(Config.jobs)
        for i = 1, #result do
            local playername = {}
            local additionalinfo = {}
            playername[1], playername[2] = result[i].name:match("(%w+)(.+)")

            local isadmin, ping =  lib.callback.await('scoreboard:getextra', false, result[i].source)

            if Config.additionalinfo then
                additionalinfo = {
                    result[i].identifier,
                    result[i].job.label,
                    result[i].gender,
                }
            end

            options[#options + 1] = {
                id = result[i].playerId,
                firstname = Config.rpname and playername[1] or result[i].name,
                lastname = Config.rpname and playername[2] or '',
                ping =  ping,
                isadmin = result[i].group == Config.admingroup and true or false,
                job = result[i].job.name,
                additionalinfo = additionalinfo
            }



            for k = 1,#jobs do
                if jobs[k].name == result[i].job.name then
                    jobs[k].count = jobs[k].count + 1
                end
            end
        end
        return options, jobs
    end
end
