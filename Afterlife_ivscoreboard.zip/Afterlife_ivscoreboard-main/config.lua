local Themes = {
    ['DarkOrange'] = {
        primary = '#e08b28',
        background = '#161616e5',
        backgroundaccent = '#9c9c9c00',
        backgroundplayers = '#c07621d9',
        textcolor = '#e0e0e0',
    },
    ['DarkRed'] = {
        primary = '#d45353',
        background = '#161616e5',
        backgroundaccent = '#9c9c9c00',
        backgroundplayers = '#d45353b2',
        textcolor = '#e0e0e0',
    },
    ['Dark'] = {
        primary = '#333333',
        background = '#131313',
        backgroundaccent = '#222222',
        backgroundplayers = '#1B1B1B',
        textcolor = '#D6D6D6',
    },
    ['Blue'] = {
        primary = '#445f96',
        background = '#1e2b44e5',
        backgroundaccent = '#90a0c0d4',
        backgroundplayers = '#2d3e61',
        textcolor = '#e0e0e0',
    },
    ['Green'] = {
        primary = '#449658',
        background = '#19331be7',
        backgroundaccent = 'transparent',
        backgroundplayers = '#2d6138',
        textcolor = '#e0e0e0',
    }
}

GetFramework = function()
    if GetResourceState('es_extended') ~= 'missing' then
        return 'esx'
    elseif GetResourceState('qbx_core') ~= 'missing' then
        return 'qbx'
    elseif GetResourceState('qb-core') ~= 'missing' then
        return 'qb'
    end
end



Config = {
    rpname = true,         -- set this to false if you dont want to show the rp name on the list
    additionalinfo = true, -- set this to false if you dont want to show the additional info of the player

    showadmin = true,
    admingroup = 'admin',

    Robberies = {
        {
            id = 'vangelico',
            title = 'Vengelico Robbery',
            description = 'Vengelico is the finest place for buying gifts for your loved ones and you can fucking rob it',
            policerequired = 4,
            coords = vec3(-633.4003, -238.8362, 38.0679)
        },
        {
            id = 'aircraft',
            title = 'Aircraft Robbery',
            description = 'Steal the dark secrets hidden on the aircraft from the sea of los santos',
            policerequired = 8,
            coords = vec3(3016.7898, -4608.3721, 18.9226)
        },
        {
            id = 'pacific',
            title = 'Pacific Robbery',
            description = 'Public Deposits are too good to not steal from pacific bank',
            policerequired = 6,
            coords = vec3(194.0023, 201.2947, 122.533)
        },
        {
            id = 'fleeca',
            title = 'Fleeca Robbery',
            description = 'have a chance to rob innocent people money from fleeca bank but dont worry they are already doomed',
            policerequired = 4,
            coords = vec3(-2972.6824, 480.6433, 16.7153)
        },
    },

    jobs = {
        {
            name = 'police',
            label = 'Law Enforcement',
            count = 0 -- dont change this
        },
        {
            name = 'ambulance',
            label = 'Medical Staff',
            count = 0 -- dont change this
        },
        {
            name = 'mechanic',
            label = 'Mechanics',
            count = 0 -- dont change this
        },
        {
            name = 'cardealer',
            label = "Car Dealers",
            count = 0 -- dont change this
        }
    },

    ranks = {
        {
            title = 'Player of the week',
            name = 'Usman Bin Saleem',
            color = '#d6791c'
        },

    },
    leaderboard = true, -- Set this to false if you dont want the leaderboard section

    theme = Themes['Blue'],
    framework = GetFramework() -- qbx / esx / qb
}
