fx_version 'adamant'

game 'gta5'
description ''
lua54 'yes'

version '1.0'


shared_scripts {
	'config.lua',
	'util.lua',
	'@ox_lib/init.lua'
}

server_scripts {
	'server/main.lua',
	'framework/server/*.lua'
}

client_scripts {
	'client/main.lua',
	'framework/client/*.lua'
}

escrow_ignore {
	'config.lua',
	'framework/client/*.lua'
}

ui_page 'ui/dist/index.html'

files {
	'ui/dist/index.html',
	'ui/images/*.png',
	'ui/dist/assets/*.js',
	'ui/dist/assets/*.css',
	'ui/dist/assets/*.ttf'
}