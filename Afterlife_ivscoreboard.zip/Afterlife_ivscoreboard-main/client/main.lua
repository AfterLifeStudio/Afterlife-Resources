
OpenMenu =  function(action)
	local result = lib.callback.await('scoreboard:getplayers')
	local options,jobscount = ReturnTable(result)


	NuiMessage(action, {jobs = jobscount,players = options,robberies = Config.Robberies})

	if action == 'open' then
		PlaySoundFrontend(-1, "FocusIn",  "HintCamSounds",  0)
		NuiControl(true)	
	end
end


RegisterNetEvent('scoreboard:updateplayers', function ()
	OpenMenu('update')
end)

lib.addKeybind({
    name = 'Scoreboard',
    description = 'Scoreboard',
    defaultKey = 'U',
    onPressed = function ()
		OpenMenu('open')
	end,
})


RegisterNUICallback('close', function(payload, cb)
	PlaySoundFrontend(-1, "FocusOut",  "HintCamSounds",  0)
	NuiControl(false)
    cb { {} }
end)


RegisterNUICallback('getConfig', function(payload, cb)
    cb(Config)
end)


RegisterNUICallback('mark', function(data, cb)
    PlaySoundFrontend(-1, "BACK", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0)

	for i = 1, #Config.Robberies do
		print(Config.Robberies[i].id,data)
		if Config.Robberies[i].id == data then
			SetNewWaypoint(Config.Robberies[i].coords.x,Config.Robberies[i].coords.y)
			break
		end
	end
    cb { {} }
end)




RegisterNUICallback('hover', function(data, cb)
    PlaySoundFrontend(-1, "Cycle_Item", 'DLC_Dmod_Prop_Editor_Sounds', 0)
    cb { {} }
end)

RegisterNUICallback('click', function(data, cb)
    PlaySoundFrontend(-1, "BACK", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0)
    cb { {} }
end)
