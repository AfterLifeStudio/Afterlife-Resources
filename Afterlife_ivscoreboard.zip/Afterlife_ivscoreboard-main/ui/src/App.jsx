import { useState } from 'react'
import './App.css'
import Scoreboard from './components/Scoreboard'
import { createTheme, MantineProvider } from '@mantine/core';
import {emotionTransform, MantineEmotionProvider,} from '@mantine/emotion';

import { useConfig } from './providers/configprovider';

const theme = createTheme({
  primary: '#D9D9D9',
  background: 'rgba(0,0,0,0.9)',
  backgroundaccent: '#9c9c9c00',
  backgroundplayers: '#c07621d9',
  textcolor: '#e0e0e0',
});

function App() {

  const { config } = useConfig();


  return (
    <>

    <MantineProvider theme={{...theme , ...config.theme}}>
      <MantineEmotionProvider>
        {/* <div style={{backgroundColor: '#101010',width: '150vw',height: '150vw',transform: 'translate(-10%,-10%)'}}></div> */}
        <Scoreboard config={config}  />
        </MantineEmotionProvider>
    </MantineProvider>
    </>
  )
}

export default App
