import usericon from "../assets/user-regular.svg";
import { createStyles } from '@mantine/emotion';
import { details } from "./table";
import { useMantineTheme } from '@mantine/core';
import { setClipboard } from "../utils/setClipboard";
import { nuicallback } from "../utils/nuicallback";

const useStyles = createStyles((theme) => ({
  playerwrapper: {
    color: 'white',
    "&:hover": {
      backgroundColor: '#D9D9D9',
      cursor: "pointer",
      color: 'black',
    }
  },
  playercontainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: '10px 0px',
  },

  icon: {
    width: 15,
    filter: 'invert()'
  },
  name:{

    width: 250,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  job: {

    width: 180,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },

  ping: {

    width: 80,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },

  playerid: {

    width: 50,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  infoscontainer: {
    display: 'flex',
    flexDirection: 'row',
    gap: 5,
    padding: 10
  },
  additionalinfos: {
    '&:hover':{

    },
    backgroundColor: 'black',
    fontSize: 13,
    color: '#D9D9D9',
    padding: '0px 5px 0px 5px',
    width: 'fit-content',
    overflow: 'hidden',
    textOverflow: 'ellipsis'
  },
  shield: {
    width: 21,
    opacity: '50%',
    filter: 'invert()'
  }


}));


const Player = ({config,player,catagory,selectedplayer,handleclick}) => {

  const { classes } = useStyles();
  const theme = useMantineTheme();

  const Copyclipboard = (text) => {
    setClipboard(text)
  }



    return (
              <div style={{padding: 5}}>
                <div 
                onMouseEnter={() => nuicallback('hover')}
                  style={selectedplayer == player.id ? {backgroundColor: '#D9D9D9',color: 'black'} : {}}
                  className={classes.playerwrapper}
                  onClick={handleclick}
                >

                  <div className={classes.playercontainer}>

                    <div className={classes.playerid}>
                      <div>{player.id}</div>
                    </div>
 
                      <div className={classes.name}>
                          <div>
                          {player.firstname + player.lastname}
                          </div>
                      </div>

                      <div className={classes.job}>
                        <div>{player.job}</div>
                      </div>

                      <div style={{
                        color: player.ping < 80 ? '#98BD73' : player.ping > 120 ? '#DD5F5F' : '#D3D370'
                      }} className={classes.ping}>
                        <div>{player.ping}ms</div>
                      </div>
            
           

                  </div>
                  {selectedplayer == player.id && (
                    <div className={classes.infoscontainer}>
                      {player.additionalinfo.map((data) => (
                        <div onClick={() => Copyclipboard(data)} className={classes.additionalinfos}>
                          <div>{data}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
    )
}

export default Player