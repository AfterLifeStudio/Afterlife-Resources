import { React, useState, useEffect } from "react";
import { table, details, ranks } from "./table";
import Player from "./players";
import Catagory from "./catagory";
import searchicon from "../assets/magnifying.svg";
import { Virtuoso } from "react-virtuoso";
import { createStyles } from "@mantine/emotion";
import { nuicallback } from "../utils/nuicallback";

import Robberies from "./robberies";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "absolute",
    top: 0,
    left: 0,
    gap: 5,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    animation: "fadein 0.5s forwards",
    animationIterationCount: 1,
    fontFamily: "Inter",
    userSelect: "none",
    width: "100%",
    height: "100%",
  },
  scoreboardwrapper: {
    backgroundColor: "rgba(0,0,0,0.9)",
    width: 1280,
    height: 720,
    display: "flex",
    flexDirection: "column",
    justifyContent: "start",
    alignItems: "center",
    gap: 25,
  },

  scoreboardheader2: {
    display: "flex",
    alignItems: "center",

    gap: 30,
    width: "80%",
  },

  scoreboardheader: {
    marginTop: 60,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 30,
    width: "80%",
  },

  logo: {
    width: 120,
  },

  headerbutton: {
    // backgroundColor: 'black',
    color: "white",
    padding: "2px 5px",
    fontWeight: "bold",
    borderBottom: "2px solid rgba(0,0,0,0)",
    "&:hover": {
      borderBottom: "2px solid white",
      // backgroundColor: 'white',
      // color: 'black',
    },
  },

  searchcontainer: {
    display: "flex",
    flexDirection: "row",
    position: "relative",
    left: 160,
  },
  searchinput: {
    width: 350,
    height: 25,
    paddingLeft: 10,
    border: "none",
    outline: "none",
    backgroundColor: "#d9d9d938",
    color: theme.textcolor,
    "&:focus": {
      backgroundColor: "#d9d9d964",
    },
    "&:hover": {
      backgroundColor: "#d9d9d964",
    },
  },
  searchicon: {
    position: "relative",
    right: 25,
    width: 15,
    filter: "invert()",
  },
  exit: {
    color: "black",
    backgroundColor: "white",
    padding: "3px 8px",
    fontWeight: "bold",
    "&:hover": {
      opacity: 0.7,
    },
  },

  maincontainer: {
    display: "flex",
    width: "100%",
    justifyContent: "center",
    width: "100%",
    height: 460,
    gap: 45,
  },
  playercontainer: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    gap: 25,
    alignItems: "center",
    width: 700,
  },
  players: {
    width: "100%",
    height: "100%",
  },

  playerheading: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "99%",
  },

  name: {
    color: theme.textcolor,
    width: 250,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  job: {
    color: theme.textcolor,
    width: 180,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  ping: {
    color: theme.textcolor,
    width: 80,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  playerid: {
    color: theme.textcolor,
    width: 50,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  line: {
    width: 2,
    height: "100%",
    background:
      "linear-gradient(180deg, rgba(223, 223, 223,0.4) 0%, rgba(233, 233, 233, 0) 100%);",
  },
}));

const Scoreboard = (configs) => {
  const [visible, setVisible] = useState(false);
  const [menu, setMenu] = useState("players");
  const [data, setData] = useState(table);
  const [robberies, setRobberies] = useState([
    {
      id: "aircraft",
      title: "Aircraft Robbery",
      description:
        "Steal the dark secrets hidden on the aircraft from the sea of los santos",
      policerequired: 8,
    },
    // {
    //     id: 'vangelico',
    //     title: 'Vengelico Robbery',
    //     description: 'Vengelico is the finest place for buying gifts for your loved ones and you can fucking rob it',
    //     policerequired: 4,
    // },
    // {
    //     id: 'pacific',
    //     title: 'Pacific Robbery',
    //     description: 'Public Deposits are too good to not steal from pacific bank',
    //     policerequired: 6,
    // },
    // {
    //     id: 'fleeca',
    //     title: 'Fleeca Robbery',
    //     description: 'have a chance to rob innocent people money from fleeca bank but dont worry they are already doomed',
    //     policerequired: 4,
    // },
  ]);

  const [catagory, setCaragory] = useState("all");
  const [jobs, setJobs] = useState([]);
  const [selectedplayer, setSelectedplayer] = useState(0);
  const [displayplayers, setDisplayplayers] = useState("");
  const [filtereddata, setfiltereddata] = useState([]);
  const config = configs.config;



  const { classes } = useStyles();

  const exit = () => {
    setVisible(false);
    setSelectedplayer(0);
    setCaragory("all");
    nuicallback("close");
  };
  const handleclick = (job) => {
    if (catagory == job) {
      return;
    }

    nuicallback("click");
    setCaragory(job);
    const filtered = data.filter((player) => {
      if (
        (displayplayers == "" ||
          player.firstname
            .toLowerCase()
            .includes(displayplayers.toLowerCase())) &&
        (job == player.job || job == "all")
      ) {
        return true;
      }
    });
    setfiltereddata(filtered);
  };

  const handleclickplayer = (id) => {
    nuicallback("click");

    if (selectedplayer == id) {
      setSelectedplayer(0);

      return;
    }
    setSelectedplayer(id);
  };

  const handlesearch = (e) => {
    setDisplayplayers(e.target.value);
    const filtered = data.filter((player) => {
      if (
        (e.target.value == "" ||
          player.firstname
            .toLowerCase()
            .includes(e.target.value.toLowerCase())) &&
        (catagory == player.job || catagory == "all")
      ) {
        return true;
      }
    });
    setfiltereddata(filtered);
  };

  useEffect(() => {
    const handlemessage = (message) => {
      const action = message.data.action;
      const data = message.data.data;

      switch (action) {
        case "open":
          setRobberies(data.robberies);
          setJobs(data.jobs);
          setData(data.players);
          setfiltereddata(data.players);
          setVisible(true);
          break;

        case "close":
          setVisible(false);
          setSelectedplayer(0);
          setCaragory("all");
          break;

        case "update":
          setJobs(data.jobs);
          setData(data.players);
          break;
      }
    };

    window.addEventListener("message", handlemessage);
    return () => window.removeEventListener("message", handlemessage);
  });

  useEffect(() => {

    const handlekey = (e) => {
      if (visible && e.code == 'Escape') {
        exit();
      }
    };

    window.addEventListener('keydown',handlekey);
    return () => window.removeEventListener('keydown',handlekey);
  })


  return (
    visible && (
      <>
        <div className={classes.wrapper}>
          <div className={classes.scoreboardwrapper}>
            <div className={classes.scoreboardheader}>
              <div className={classes.scoreboardheader2}>
                <img className={classes.logo} src="../images/logo.png" alt="" />
                <div
                  onMouseEnter={() => nuicallback("hover")}
                  onClick={() => {
                    setMenu("players");
                    nuicallback("click");
                  }}
                  style={
                    menu == "players"
                      ? { backgroundColor: "white", color: "black" }
                      : {}
                  }
                  className={classes.headerbutton}
                >
                  Players
                </div>
                <div
                  onMouseEnter={() => nuicallback("hover")}
                  onClick={() => {
                    setMenu("robberies");
                    nuicallback("click");
                  }}
                  style={
                    menu == "robberies"
                      ? { backgroundColor: "white", color: "black" }
                      : {}
                  }
                  className={classes.headerbutton}
                >
                  Robberies
                </div>
              </div>

              <div onMouseEnter={() => nuicallback('hover')} onClick={exit} className={classes.exit}>
                ESC
              </div>
            </div>

            {menu == "players" ? (
              <>
                <div onMouseEnter={() => nuicallback('hover')} className={classes.searchcontainer}>
                  <input
                    className={classes.searchinput}
                    placeholder="Search"
                    onInput={handlesearch}
                    type="text"
                  />
                  <img className={classes.searchicon} src={searchicon} alt="" />
                </div>

                <div className={classes.maincontainer}>
                  <Catagory
                    job={jobs}
                    catagory={catagory}
                    playercount={data.length}
                    handleclick={handleclick}
                  />

                  <div className={classes.line}></div>

                  <div className={classes.playercontainer}>
                    <div className={classes.playerheading}>
                      <div className={classes.playerid}>
                        <div>ID</div>
                      </div>

                      <div className={classes.name}>
                        <div>NAME</div>
                      </div>

                      <div className={classes.job}>
                        <div>JOB</div>
                      </div>

                      <div className={classes.ping}>
                        <div>PING</div>
                      </div>
                    </div>

                    <div className={classes.players}>
                      <Virtuoso
                        data={filtereddata}
                        itemContent={(k, player) => (
                          <Player
                            key={player.id}
                            config={config}
                            player={player}
                            catagory={catagory}
                            selectedplayer={selectedplayer}
                            handleclick={() => handleclickplayer(player.id)}
                          />
                        )}
                      />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Robberies robberydata={robberies} />
              </>
            )}
          </div>
        </div>
      </>
    )
  );
};

export default Scoreboard;
