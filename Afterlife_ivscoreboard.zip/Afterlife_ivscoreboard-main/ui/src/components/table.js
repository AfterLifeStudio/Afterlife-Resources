
export const table = [
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        ping: '60',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        ping: '112',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        ping: '150',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        ping: '120',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        ping: '120',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'cardealer',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },

    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 1
    },
    {
        firstname: 'Besho',
        lastname: 'Cake',
        job: 'police',
        id: 2
    },
    {
        firstname: 'Brazy',
        lastname: 'Parker',
        job: 'mechanic',
        id: 3
    },
    {
        firstname: 'Jeason',
        lastname: 'Dash',
        job: 'ems',
        id: 4
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 5
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 6
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 7
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 8
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'ems',
        id: 9
    },
    {
        firstname: 'Usman',
        lastname: 'saleem',
        job: 'police',
        id: 10 
    },
]

export const details = [
    '123dasdac1asdasd23123d21d1dassssssaasdasdasdasf',
    'Mechanic',
]

export const jobs = [
    {
        name: 'police',
        label: 'Law Enforcement'
    },
    {
        name: 'ambulance',
        label: 'Medical Staff'
    },
    {
        name: 'mechanic',
        label: 'Mechanics'
    },
    {
        name: 'cardealer',
        label: "Car Dealers"
    }
]

export const ranks = [
    {
        title: 'Player of the week',
        name: 'Usman Bin Saleem',
        color: '#d6791c'
    }
]

export const jobtable = [
    {

        job: 'police',
        bg: '#0284c7'
    },
    {

        job: 'ems',
        bg: '#dc2626'
    },
    {

        job: 'mechanic',
        bg: '#64748b'
    },
        
]


export const theme = {
    primary: '#449658',
    background: '#131313',
    backgroundaccent: '#3b3b3b00',
    backgroundplayers: '#2d6138',
    textcolor: '#e0e0e0',
}

