import { React, useState, useEffect } from "react";
import { createStyles } from "@mantine/emotion";
import { nuicallback } from "../utils/nuicallback";
import hoversound from "../assets/hover.wav";

const useStyles = createStyles((theme) => ({
  wrapper: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "start",
    gap: 20,
    width: "80%",
    overflow: "scroll",
    alignItems: "center",
  },
}));

const Robberies = (data) => {
  const { classes } = useStyles();
  const robberydata = data.robberydata 
console.log(robberydata)
  return (

      <>
      <div className="hline"></div>
        <div className={classes.wrapper}>
          {robberydata.map(data => 
          <div
            style={{
              backgroundImage: `radial-gradient(circle, rgba(0,0,0,0) 0%, rgba(0,0,0,0.8) 100%), url(../images/${data.id}.png), url(../images/${data.id}.PNG)`,
            }}
            onMouseEnter={() => nuicallback('hover')}
            className="robbery"
          >
            <div className="circle">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                <path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" />
              </svg>
            </div>
            <div className="robbery-info">
              <div className="info-padding">
                <div className="robbery-title">{data.title}</div>
                <div className="robbery-required">
                  {data.description}
                </div>

                <div className="bottom">
                  <div className="policecount">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 640 512"
                    >
                      <path d="M240 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM192 48a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm-32 80c17.7 0 32 14.3 32 32l8 0c13.3 0 24 10.7 24 24l0 16c0 1.7-.2 3.4-.5 5.1C280.3 229.6 320 286.2 320 352c0 88.4-71.6 160-160 160S0 440.4 0 352c0-65.8 39.7-122.4 96.5-146.9c-.4-1.6-.5-3.3-.5-5.1l0-16c0-13.3 10.7-24 24-24l8 0c0-17.7 14.3-32 32-32zm0 320a96 96 0 1 0 0-192 96 96 0 1 0 0 192zm192-96c0-25.9-5.1-50.5-14.4-73.1c16.9-32.9 44.8-59.1 78.9-73.9c-.4-1.6-.5-3.3-.5-5.1l0-16c0-13.3 10.7-24 24-24l8 0c0-17.7 14.3-32 32-32s32 14.3 32 32l8 0c13.3 0 24 10.7 24 24l0 16c0 1.7-.2 3.4-.5 5.1C600.3 229.6 640 286.2 640 352c0 88.4-71.6 160-160 160c-62 0-115.8-35.3-142.4-86.9c9.3-22.5 14.4-47.2 14.4-73.1zm224 0a96 96 0 1 0 -192 0 96 96 0 1 0 192 0zM368 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm80 48a32 32 0 1 1 0 64 32 32 0 1 1 0-64z" />
                    </svg>
                    <div>{data.policerequired}</div>
                  </div>

                  <div className="setwaypoint">
                  <div onClick={() => nuicallback('mark',data.id)}>Mark</div>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
      </>
    )
};

export default Robberies;
