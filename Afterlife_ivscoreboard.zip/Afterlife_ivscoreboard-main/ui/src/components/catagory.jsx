import { createStyles } from '@mantine/emotion';
import { useMantineTheme } from '@mantine/core';
import { useState } from 'react';
import { useEffect } from 'react';
import { jobs } from './table';
import { nuicallback } from '../utils/nuicallback';

const useStyles = createStyles((theme) => ({

  jobscontainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: 10,
    width: 'fit-content',
    height: '100%',
    overflowY: 'scroll',
  },

  alljob: {
    '&:hover': {
      backgroundColor: '#C9C9C9',
      cursor: 'pointer',
      color: 'black',
      fill: 'black'
    },
    fill: 'white',
    color: 'white',
    backgroundSize: 250,
    backgroundPosition: 'center',
    border: '1px solid white',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 11,
    transition: '0.2s ease',
    width: 220,
minHeight: 25
  },
  job: {
    '&:hover': {
      cursor: 'pointer',
      backgroundSize: '280px !important',
    },
    color: 'white',
    backgroundSize: 250,
    backgroundPosition: 'center',
    border: '1px solid white',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'start',
    padding: 11,
    transition: '100ms ease',

    width: 220,
    minHeight: 100,
  },
  jobtitle: {

    fontWeight: 'bold',
    overflowX: 'hidden',
    textTransform: 'uppercase'
  },
  jobcount: {

    padding: '0px 5px 0px 5px',
    height: 25,
    fontSize: 18,
    gap: 5,
    borderRadius: 10,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  }

}))

const Catagory = ({job, catagory, playercount, handleclick }) => {
  const { classes } = useStyles();
  const theme = useMantineTheme();

  
  return (

      <div className={classes.jobscontainer}>
        <div
          onClick={() => handleclick('all')}
          onMouseEnter={() => nuicallback('hover')}
          style={ catagory == 'all' ?{backgroundColor: '#C9C9C9',color: 'black',fill: 'black'} : {}}
          className={classes.alljob}
        >
          <div className={classes.jobtitle}>
            PLAYERS
          </div>
          <div className={classes.jobcount} >
          <svg className={classes.counticon} xmlns="http://www.w3.org/2000/svg" width={15}  viewBox="0 0 448 512"><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z"/></svg>
            <div>{playercount}/48</div>
          </div>
        </div>
        {job.map((job) => (
            <div
              onClick={() => handleclick(job.name)}
              onMouseEnter={() => nuicallback('hover')}
              style={{backgroundImage: `radial-gradient(circle, rgba(0,0,0,0) 0%, rgba(0,0,0,0.8) 100%), url(../images/${job.name}.png), url(../images/${job.name}.PNG)`,backgroundSize: catagory == job.name ? '280px' : ''}}
              className={classes.job}
            >
              <div className={classes.jobtitle}>
                {job.label}
              </div>
              <div className={classes.jobcount} >
              <svg xmlns="http://www.w3.org/2000/svg" width={15} fill='white' viewBox="0 0 448 512"><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z"/></svg>
                <div>{job.count}</div>
              </div> 
            </div>
          ))}
      </div>

  );
};

export default Catagory;