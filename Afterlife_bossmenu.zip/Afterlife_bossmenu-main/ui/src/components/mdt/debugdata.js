
export const gradedata = [
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
    {
        id: 0,
        label: 'Boss'
    },
]


export const dasboarddata  = {
        job: 'sapd',
        playerfirstname: 'Osman',
        playername: 'Osman Saleem',
        playerrank: 'Seargent',
        locationlabel: 'Mission Row',
        locationdescription: 'Police department located nearthe legion square',
        jobcount: 12,
        accountmoney: 123214124,
        nearbyplayers: [
            {
                id: 1,
                name: 'Osman Saleem'
            },
            {
                id: 1,
                name: 'Osman Saleem'
            },            {
                id: 1,
                name: 'Osman Saleem'
            },
            {
                id: 1,
                name: 'Osman Saleem'
            },
            {
                id: 1,
                name: 'Osman Saleem'
            }
        ]
    }


export const employdata = [
    {
        name: 'Osman Saleem',
        gender: 'male',
        rank: 'chief',
        salary: 600,
        status: true
    },
    {
        name: 'Osmans Saleem',
        gender: 'male',
        rank: 'chief',
        salary: 600,
        status: true
    },
    
    {
        name: 'Osman Saleem',
        gender: 'male',
        rank: 'chief',
        salary: 600,
        status: true
    },
    {
        name: 'Osman Saleem',
        gender: 'male',
        rank: 'chief',
        salary: 600,
        status: true
    },
    {
        name: 'Osman Saleem',
        gender: 'male',
        rank: 'chief',
        salary: 600,
        status: true
    },
    
]

