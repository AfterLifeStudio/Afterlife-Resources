import { useState } from "react"
import { nuicallback } from '../../utils/nuicallback'


const Dashboard = (e) => {
    const data = e.data
    const [moneyinput, setMoneyInput] = useState(0);

    return (
        <>
            <div className="dashboard">

                <div className="dashboard-header">
                    <div>
                        <div className="dashboard-title">Hi {data.playerfirstname},</div>
                        <div className="dashboard-description">WELCOME TO
                            MANAGEMENT TERMINAL</div>
                    </div>

                    <div className="profile">
                        <div className="profile-image">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z" /></svg>
                        </div>
                        <div  className="profile-info">
                            <div className="name">{data.playername}</div>
                            <div className="grade">{data.playerrank}</div>
                        </div>
                    </div>

                </div>

                <div className="dashboard-bottom">
                    <div style={{backgroundImage: `var(--gradient2), url('../images/${data.id}.png')`}} className="dashboard-location">
                        <div className="dashboard-bottom-inner">

                            <div className="dashboard-location-top">
                                <div >
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z" /></svg>
                                    <div className="dashboard-location-title">{data.locationlabel}</div>
                                </div>
                                <div className="dashboard-location-description" >{data.locationdescription}</div>
                            </div>

                            <div className="dashboard-location-bottom">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M144 0a80 80 0 1 1 0 160A80 80 0 1 1 144 0zM512 0a80 80 0 1 1 0 160A80 80 0 1 1 512 0zM0 298.7C0 239.8 47.8 192 106.7 192l42.7 0c15.9 0 31 3.5 44.6 9.7c-1.3 7.2-1.9 14.7-1.9 22.3c0 38.2 16.8 72.5 43.3 96c-.2 0-.4 0-.7 0L21.3 320C9.6 320 0 310.4 0 298.7zM405.3 320c-.2 0-.4 0-.7 0c26.6-23.5 43.3-57.8 43.3-96c0-7.6-.7-15-1.9-22.3c13.6-6.3 28.7-9.7 44.6-9.7l42.7 0C592.2 192 640 239.8 640 298.7c0 11.8-9.6 21.3-21.3 21.3l-213.3 0zM224 224a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zM128 485.3C128 411.7 187.7 352 261.3 352l117.3 0C452.3 352 512 411.7 512 485.3c0 14.7-11.9 26.7-26.7 26.7l-330.7 0c-14.7 0-26.7-11.9-26.7-26.7z" /></svg>
                                <div>{data.jobcount}</div>
                            </div>
                        </div>
                    </div>
                    <div className="dashboard-accounts">
                        <div className="dashboard-bottom-inner">

                            {/* <div style={{display: 'flex',flexDirection: 'column',gap: '20px'}}> */}




                            <div className="dasboard-account-header">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zm48 160l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zM96 336c0-8.8 7.2-16 16-16l352 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-352 0c-8.8 0-16-7.2-16-16zM376 160l80 0c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24l0-48c0-13.3 10.7-24 24-24z" /></svg>
                                <div className="account-label">
                                    <div className="title">Shared Account</div>
                                    <div className="description">{data.job}@...com</div>
                                </div>
                            </div>



                            <div>
                                <div className="balance-title">Account Balance</div>
                                <div className="balance">${data.accountmoney}</div>
                            </div>

                            {/* </div> */}

                            <div className="accounts-bottom">
                                <div className="balance-input">
                                    <input onChange={(e) => setMoneyInput(e.target.value)} placeholder="Amount" type="number" />
                                    <div>$</div>
                                </div>

                                <div className="balance-actions">
                                    <div onClick={() => {
                                                  if (moneyinput > 0){
                                        nuicallback('withdraw:balance', {job: data.job,amount: moneyinput}).then(e.updateaccountbalance)
                                                  }
                                    }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M169.4 470.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 370.8 224 64c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 306.7L54.6 265.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"/></svg>
                                        <p>Withdraw</p>
                                    </div>
                                    <div onClick={() => {
                                        if (moneyinput > 0){
                                        nuicallback('deposit:balance', {job: data.job,amount: moneyinput}).then(e.updateaccountbalance)
                                        }
                                    }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M214.6 41.4c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 141.2 160 448c0 17.7 14.3 32 32 32s32-14.3 32-32l0-306.7L329.4 246.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-160-160z"/></svg>
                                        <p>Deposit</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="dashboard-hire">
                        <div className="dashboard-bottom-inner">

                            <div className="dashboard-location-top">
                                <div>
                                <svg style={{width: '25px'}} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M144 0a80 80 0 1 1 0 160A80 80 0 1 1 144 0zM512 0a80 80 0 1 1 0 160A80 80 0 1 1 512 0zM0 298.7C0 239.8 47.8 192 106.7 192l42.7 0c15.9 0 31 3.5 44.6 9.7c-1.3 7.2-1.9 14.7-1.9 22.3c0 38.2 16.8 72.5 43.3 96c-.2 0-.4 0-.7 0L21.3 320C9.6 320 0 310.4 0 298.7zM405.3 320c-.2 0-.4 0-.7 0c26.6-23.5 43.3-57.8 43.3-96c0-7.6-.7-15-1.9-22.3c13.6-6.3 28.7-9.7 44.6-9.7l42.7 0C592.2 192 640 239.8 640 298.7c0 11.8-9.6 21.3-21.3 21.3l-213.3 0zM224 224a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zM128 485.3C128 411.7 187.7 352 261.3 352l117.3 0C452.3 352 512 411.7 512 485.3c0 14.7-11.9 26.7-26.7 26.7l-330.7 0c-14.7 0-26.7-11.9-26.7-26.7z"/></svg>
                                    <div className="dashboard-location-title">Hire</div>
                                </div>
                                <div className="dashboard-location-description" >Here you can hire employees</div>
                            </div>


                            <div className="hire-wrapper">
                                <div className="hire-title">Nearby Civilians</div>

                                <div className="hire-container">

                                    {data.nearbyplayers.map(player => (
                                    <div className="hire-employee">
                                        <div  className="hire-id">{player.id}</div>
                                        <div className="hire-name">{player.name}</div>

                                        <div className="hire-button">
                                        <div className="hover">Hire</div>
                                       <svg onClick={() => nuicallback('Hire', {id: player.id, job: data.job}).then(e.updatenearbyplayers)} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M96 128a128 128 0 1 1 256 0A128 128 0 1 1 96 128zM0 482.3C0 383.8 79.8 304 178.3 304l91.4 0C368.2 304 448 383.8 448 482.3c0 16.4-13.3 29.7-29.7 29.7L29.7 512C13.3 512 0 498.7 0 482.3zM504 312l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"/></svg>
                                       </div>
                                    </div>
                                    ))}

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Dashboard